import java.applet.Applet;

public class GameStart2 extends Applet {

	
	

}
